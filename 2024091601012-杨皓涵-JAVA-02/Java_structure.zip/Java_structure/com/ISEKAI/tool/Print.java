package com.ISEKAI.tool;

public class Print {
    public static void print(String str) {
        System.out.println(str);
    }
}
